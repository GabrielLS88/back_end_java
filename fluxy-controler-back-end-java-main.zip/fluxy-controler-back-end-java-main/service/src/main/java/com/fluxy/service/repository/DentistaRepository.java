package com.fluxy.service.repository;

import com.fluxy.service.modal.Dentista;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DentistaRepository extends JpaRepository<Dentista, Long> {}
