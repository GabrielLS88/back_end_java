package com.fluxy.service.repository;

import com.fluxy.service.modal.Servico;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ServicoRepository extends JpaRepository<Servico, Long> {}
