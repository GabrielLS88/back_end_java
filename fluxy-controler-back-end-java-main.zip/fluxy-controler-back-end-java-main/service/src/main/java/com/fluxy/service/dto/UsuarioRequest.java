package com.fluxy.service.dto;

public class UsuarioRequest {
}
