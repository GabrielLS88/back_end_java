package com.fluxy.service.repository;
import com.fluxy.service.modal.Recibo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReciboRepository extends JpaRepository<Recibo, Long> {}

